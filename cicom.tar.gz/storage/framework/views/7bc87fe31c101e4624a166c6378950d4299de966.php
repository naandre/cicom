<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/jaime/www/sitio/html/cicom/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/button.blade.php ENDPATH**/ ?>