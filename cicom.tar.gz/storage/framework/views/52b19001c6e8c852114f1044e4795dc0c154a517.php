<?php $__env->startSection(config('toaster.content')); ?>
    <div class="uk-container">
        <div>
            <h2>
                <b><?php echo e(config('app.name')); ?></b>
                <br />
                Bienvenido al Administrador de Contenido
            </h2>
            <hr />
            <h4>
                Selecciona una de las opciones del menu, que se encuentra ubicado en la parte superior izquierda
            </h4>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make(config('toaster.template'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jaime/www/sitio/html/cicom/resources/views/backend/dashboard.blade.php ENDPATH**/ ?>