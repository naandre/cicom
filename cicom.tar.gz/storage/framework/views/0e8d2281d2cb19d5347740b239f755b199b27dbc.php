<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Tienda online')); ?></title>

    <!-- Styles -->


    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/uikit/3.0.0-beta.40/css/uikit.min.css"/>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/uikit/3.0.0-beta.40/js/uikit.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/uikit/3.0.0-beta.40/js/uikit-icons.min.js"></script>

</head>
<body>

<div class="uk-offcanvas-content">


    <nav class="uk-navbar-container">
        <div class="uk-container">
            <div uk-navbar="" class="uk-navbar">
                <div class="uk-navbar-left">

                    <ul class="uk-navbar-nav">
                        <li class="uk-active"><a class="uk-navbar-toggle" href="#" uk-toggle="target: #offcanvas-nav">
                                <span uk-navbar-toggle-icon></span> <span class="uk-margin-small-left">Menu</span>
                            </a></li>
                    </ul>

                </div>
                <div class="uk-navbar-right">
                    <ul class="uk-navbar-nav">
                        <li>
                            <a href="#"><?php echo e(Auth::user()->name); ?></a>
                            <div class="uk-navbar-dropdown">
                                <ul class="uk-nav uk-navbar-dropdown-nav">
                                    <li><a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                           onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            Salir
                                        </a>
                                    </li>
                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST"
                                          style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </ul>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>

    <?php if(Auth::check()): ?>
        <div class="uk-offcanvas-content">
            <div id="offcanvas-nav" uk-offcanvas="overlay: true">
                <div class="uk-offcanvas-bar">
                    <h3>ADMIN</h3>
                    <button class="uk-offcanvas-close" type="button" uk-close></button>
                    <ul class="uk-nav uk-nav-default">
                        <li>
                            <a href="<?php echo route('admin.dashboard.index'); ?>">
                                <span class="uk-margin-small-right" uk-icon="icon: home"></span>
                                Dashboard
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo route('admin.users.index'); ?>">
                                <span class="uk-margin-small-right" uk-icon="icon: users"></span>
                                Ususarios
                            </a>
                        </li>
                        <hr class="uk-divider-icon">






                    </ul>
                </div>
            </div>
        </div>
    <?php endif; ?>


    <div class="uk-margin">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</div>


</body>
</html>
<?php /**PATH /home/jaime/www/sitio/html/cicom/resources/views/vendor/Toaster/Template/Layout.blade.php ENDPATH**/ ?>