<?php $__env->startSection(config('toaster.content')); ?>

    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.1.1/css/responsive.dataTables.min.css">

    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="//cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
    <script src="//cdn.datatables.net/responsive/2.1.1/js/dataTables.responsive.min.js"></script>

    <?php if(isset($color)): ?>
        <script type="text/javascript" src="<?php echo asset('public/js/jscolor.js'); ?>"></script>
    <?php endif; ?>


    <div class="uk-container">
        <div>
            <?php $__currentLoopData = \OsTheNeo\Toaster\BladeEngine::CssIncludes(@$contents); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $css): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <link rel="stylesheet" href="<?php echo e($css); ?>">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php $__currentLoopData = ['danger', 'warning', 'success', 'info']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(Session::has($key)): ?>
                    <div class="uk-alert-<?php echo e($key); ?>">
                        <a class="uk-alert-close" uk-close></a>
                        <?php echo e(Session::get($key)); ?>

                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php if($errors->any()): ?>
                <ul class="uk-alert-warning">
                    <a class="uk-alert-close" uk-close></a>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>

            <?php if(!isset($containers)): ?>
                <?php
                    if(!is_array($contents)){
                        $contents = [$contents];
                    }
                    $containers = ['contents' => $contents];
                ?>
            <?php endif; ?>

            <?php $__currentLoopData = $containers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contents): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="uk-container">
                    <?php
                        unset($contents['class']);
                    ?>


                    <?php if(isset($title)): ?>
                        <span class="uk-text-lead"><?php echo $title; ?></span>
                    <?php endif; ?>

                    <?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php if(isset($content->title)): ?>
                            <h3 class="uk-text-lead"><?php echo $content->title; ?></h3>
                        <?php endif; ?>

                        <div class="uk-container">
                            <?php $__currentLoopData = \OsTheNeo\Toaster\BladeEngine::buildButtons($content); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $position => $html): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo $html; ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <div class="uk-container">
                            <?php if($content->visualization == 'list'): ?>
                                <ul class="uk-list uk-list-striped">
                                    <?php $__currentLoopData = $content->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li> <?php echo $key; ?> : <?php echo $value; ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>

                            <?php elseif($content->visualization == 'table'): ?>
                                <table id="<?php echo $content->schema; ?>" class="uk-table uk-table-small uk-table-hover">
                                    <thead>
                                    <?php echo \OsTheNeo\Toaster\BladeEngine::table($content); ?>

                                    </thead>

                                    <?php if($content->data != null and $content->data != "ajax"): ?>
                                        <tbody>
                                        <?php $__currentLoopData = $content->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <?php $__currentLoopData = $content->model->schemas[$content->schema]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($field[0] != '_'): ?>
                                                        <td> <?php echo $row->$field; ?></td>
                                                    <?php else: ?>
                                                        <?php if($field == '_links'): ?>
                                                            <td><?php echo \OsTheNeo\Toaster\BladeEngine::buildLinks($content->model, $content->schema, $row); ?></td>
                                                        <?php endif; ?>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tbody>
                                    <?php else: ?>
                                        <script src="<?php echo e(asset('public/datatable/datatable.pipeline.js')); ?>"></script>
                                        <script>
                                            $(document).ready(function () {
                                                var table = $('#<?php echo e($content->schema); ?>').DataTable({
                                                    "columnDefs": [
                                                        {
                                                            "targets": [0],
                                                            "visible": <?php echo isset($content->visibleId)?$content->visibleId:'false'; ?>,
                                                            "searchable": false
                                                        }
                                                    ],
                                                    "order": [[<?php echo isset($content->orderBy)?$content->orderBy:'0, "desc"'; ?>]],
                                                    "processing": true,
                                                    "serverSide": true,
                                                    "pageLength": 10,
                                                    "language": {
                                                        "url": "https://cdn.datatables.net/plug-ins/1.10.12/i18n/Spanish.json"
                                                    },
                                                    "ajax": $.fn.dataTable.pipeline({
                                                        url: '<?php echo route('server.pipeline', $content->schema).(isset($content->filters)?"?".$content->filters:""); ?>',
                                                        pages: 5
                                                    })
                                                });
                                            });
                                        </script>
                                    <?php endif; ?>
                                </table>

                                <script>
                                    $(document).ready(function () {
                                        var table = $('#<?php echo e($content->schema); ?>').DataTable()
                                    });
                                </script>
                            <?php elseif($content->visualization == 'timeline'): ?>
                                <ul>
                                    <?php $__currentLoopData = $content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo \OsTheNeo\Toaster\BladeEngine::makeItemTimeline($item); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>

                            <?php elseif($content->visualization == 'form'): ?>

                                <?php
                                    $saveButton = true;
                                    if(isset($submitButton)) $saveButton = !$submitButton;
                                ?>

                                <?php if($access == 'edit'): ?>
                                    <?php echo Form::model($model, ['route' => [$model->routes[$access], $model->id], 'files'=>$model->files or false, 'method' => 'PUT', 'class'=>'uk-form-horizontal']); ?>

                                <?php else: ?>
                                    <?php $model = $models[$content->model]; ?>
                                    <?php echo Form::open(['route' => $model->routes[$access], 'files'=>$model->files or false, 'method'=>'POST', 'class'=>'uk-form-horizontal']); ?>

                                <?php endif; ?>

                                <?php if(isset($pre)): ?>
                                    <?php $__currentLoopData = $pre; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hidden): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo Form::hidden($hidden[0], $hidden[1]); ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>


                                <?php $__currentLoopData = \OsTheNeo\Toaster\BladeEngine::buildFields($content, $model); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="uk-margin">
                                        <?php echo $value->label; ?>

                                        <?php if($value->field != null): ?>
                                            <?php if(isset($value->preview)): ?>
                                                <div class="uk-margin" uk-img>
                                                    <div class="uk-form-controls">
                                                        <?php $pathFile=asset($value->preview) ?>
                                                        <img src="<?php echo e($pathFile); ?>" data-src="<?php echo e($pathFile); ?>" width="25%" alt="<?php echo e($pathFile); ?>" uk-img>
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                            <div class="uk-form-controls">
                                                <?php echo $value->field; ?>

                                            </div>

                                        <?php else: ?>
                                            <hr/>
                                            <h2><?php echo $value->include; ?></h2>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                <?php if(isset($gallery) and isset($model->id)): ?>
                                    <?php echo $__env->make('Toaster::Gallery', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php endif; ?>

                                <?php if(isset($custom)): ?>
                                    <?php echo $__env->make($custom, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php endif; ?>

                                    <?php if(!$saveButton): ?>
                                        <div class="uk-margin uk-text-center">
                                            <?php echo Form::submit('Guardar Cambios',['class'=>'uk-button uk-button-primary']); ?>

                                        </div>
                                    <?php endif; ?>

                                <?php echo Form::close(); ?>


                            <?php elseif($content->visualization == 'plain'): ?>
                                <dl>
                                    <?php $__currentLoopData = $content->rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <dt><?php echo e($row); ?></dt>
                                        <dd><?php echo e($model->$key); ?></dd>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </dl>
                            <?php endif; ?>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php if(isset($saveButton) and $saveButton): ?>
                <div class="uk-margin uk-text-center">
                    <button type="button" class="uk-button uk-button-primary" onclick="saveForms();">Guardar Cambios</button>
                </div>
            <?php endif; ?>

            <?php echo e(\OsTheNeo\Toaster\BladeEngine::defineVars()); ?>


                <?php if($content->visualization == 'form'): ?>
                    <?php if($saveButton): ?>
                        <script>
                            $("form").submit(function (e) {
                                return false;
                            });

                            function saveForms() {
                                var forms = [];
                                var action = '';
                                $("form").each(function () {
                                    if ($(this).attr('method') === 'POST') {
                                        action = $(this).attr('action');
                                        forms.push($(this).serialize());
                                    }
                                });

                                var form = $(document.createElement('form'));
                                $(form).attr("action", action);
                                $(form).attr("method", "POST");

                                var input = $("<input>").attr("type", "hidden").attr("name", "forms").val(JSON.stringify(forms));
                                $(form).append($(input));
                                var input = $("<input>").attr("type", "hidden").attr("name", "_token").val('<?php echo e(csrf_token()); ?>');
                                $(form).append($(input));

                                        <?php if($access == 'edit'): ?>
                                var input = $("<input>").attr("type", "hidden").attr("name", "_method").val('patch');
                                $(form).append($(input));
                                <?php endif; ?>

                                form.appendTo(document.body);
                                $(form).submit();

                            }
                        </script>
                    <?php endif; ?>
                    <?php if(isset($content->date)): ?>
                        <?php if(isset($content->date['date']) or isset($content->date['datetime'])): ?>
                            <link rel="stylesheet" type="text/css" href="<?php echo URL::asset('public/css/jquery.datetimepicker.min.css'); ?>" />
                            <script src="<?php echo URL::asset('public/js/jquery.datetimepicker.full.js'); ?>"></script>
                        <?php endif; ?>
                        <?php if(isset($content->date['time'])): ?>
                            <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.3/jquery.timepicker.min.css" />
                            <script src="https://cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.3/jquery.timepicker.min.js"></script>
                        <?php endif; ?>
                        <script>
                            $(document).ready(function () {
                                $.datetimepicker.setLocale('es');
                                <?php if(isset($content->date['date'])): ?>
                                $('.date').datetimepicker({
                                    dayOfWeekStart: 1,
                                    lang: 'es',
                                    timepicker: false,
                                    format: 'Y-m-d',
                                    scrollMonth : false,
                                    scrollInput : false
                                });
                                <?php endif; ?>
                                <?php if(isset($content->date['datetime'])): ?>
                                $('.datetime').datetimepicker({
                                    dayOfWeekStart: 1,
                                    lang: 'es',
                                    timepicker: true,
                                    format: 'Y-m-d h:i:s',
                                    scrollMonth : false,
                                    scrollInput : false
                                });
                                <?php endif; ?>
                                <?php if(isset($content->date['time'])): ?>
                                $('.time').timepicker({
                                    timeFormat: 'HH:mm:ss',
                                    interval: 10,
                                });
                                <?php endif; ?>
                            });
                        </script>
                    <?php endif; ?>
                <?php endif; ?>

            <?php $__currentLoopData = \OsTheNeo\Toaster\BladeEngine::JsIncludes($contents); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $js): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <link rel="stylesheet" href="<?php echo e($js); ?>">
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make(config('toaster.template'), \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jaime/www/sitio/html/cicom/resources/views/vendor/Toaster/Content.blade.php ENDPATH**/ ?>