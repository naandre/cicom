<?php echo e($slot); ?>

<?php /**PATH /home/jaime/www/sitio/html/cicom/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>